package com.continental.enums;

public enum Gender {
	MALE, FEMALE
}
