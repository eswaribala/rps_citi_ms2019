package com.continental.utility;

public class StatisticsUtility {
	public static int addIntData(int num1, int num2) {
		return num1 + num2;
	}
} 