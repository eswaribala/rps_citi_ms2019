package com.continental.business;

public class Utility {

	public static int sum(int d1, int d2)
	{
		return d1+d2;
	}
	
	public static String joinString(String s1, String s2)
	{
				
		return String.join("-->", s1,s2);
	}
	
}
