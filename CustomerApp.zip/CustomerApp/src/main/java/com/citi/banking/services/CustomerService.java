package com.citi.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.banking.models.Customer;
import com.citi.banking.repositories.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository repo;
	
	//adding the customer
	//insert query
	public Customer addCustomer(Customer customer)
	{
		return repo.save(customer);
	}
	
	public List<Customer> getAllCustomers()
	{
		return repo.findAll();
	}
	
	
	
}
