package com.citi.banking.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.banking.models.Customer;

public interface CustomerRepository extends JpaRepository<Customer,Integer>{

}
